package dimas.fauzan.myintentapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MoveWithDataActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_AGE = "extra_age"
        const val EXTRA_NAME = "extra_name"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_move_with_data)

        val tvDataReceive: TextView = findViewById(R.id.tv_data_receive)
        val age = intent.getIntExtra(EXTRA_AGE, 0)
        val name = intent.getStringExtra(EXTRA_NAME)

        val text = "Namamu $name, Umur Kamu $age"
        tvDataReceive.text = text

    }
}
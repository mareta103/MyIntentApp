package dimas.fauzan.myintentapp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMoveActivity: Button = findViewById(R.id.btn_move_activity)
        btnMoveActivity.setOnClickListener(this)

        val btnMoveWithDataActivity: Button = findViewById(R.id.btn_move_activity_with_data)
        btnMoveWithDataActivity.setOnClickListener(this)

        val btnMoveWithObjectActivity: Button = findViewById(R.id.btn_move_activity_with_object)
        btnMoveWithObjectActivity.setOnClickListener(this)

        val btnInternet: Button = findViewById(R.id.btn_internet)
        btnInternet.setOnClickListener(this)

        val btnDialPhone: Button = findViewById(R.id.btn_move_dial_phone)
        btnDialPhone.setOnClickListener(this)

    }

    override fun onClick(v: View) {
        when(v.id) {
            R.id.btn_move_activity -> {
                val moveActivity = Intent(this, MoveActivity::class.java)
                startActivity(moveActivity)
            }
            R.id.btn_move_activity_with_data -> {
                val moveWithDataActivity = Intent(this, MoveWithDataActivity::class.java)
                moveWithDataActivity.putExtra(
                    MoveWithDataActivity.EXTRA_NAME,
                    "Dimas Fauzan Nurhidayat"
                )
                moveWithDataActivity.putExtra(MoveWithDataActivity.EXTRA_AGE, 20)
                startActivity(moveWithDataActivity)
            }

            R.id.btn_move_activity_with_object -> {
                val orang = Person(
                    "Dimas Fauzan Nurhidayat",
                    20,
                    "dimaz.fauzan85@gmail.com",
                    "Semarang"

                )
                val moveWithObjectActivity = Intent (this, MoveWithObjectActivity::class.java)
                moveWithObjectActivity.putExtra(MoveWithObjectActivity.EXTRA_PERSON, orang)
                startActivity(moveWithObjectActivity)
            }

            R.id.btn_internet -> {
                val website = "https://www.polines.ac.id/id/"
                val websiteIntent = Intent(Intent.ACTION_VIEW, Uri.parse(website))
                startActivity(websiteIntent)
            }
            R.id.btn_move_dial_phone -> {
                val tel = "082232619101"
                val tellIntent = Intent(Intent.ACTION_DIAL).apply{
                    data = Uri.parse("tel:$tel")
                }
                startActivity(tellIntent)
            }
        }
    }
}